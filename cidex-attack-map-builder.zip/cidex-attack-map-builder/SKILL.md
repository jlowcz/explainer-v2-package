---
name: cidex-attack-map-builder
description: Turn CIDeX incident response reports into the animated endpoint-and-identity attack map (single HTML file). Use for building day N's map from IR reports, or adding a new day to an existing map. Bundles the engine, build, validate and test scripts.
---

# CIDeX attack map builder (from IR reports to HTML)

Output: one self-contained HTML map (inline SVG and JS, no CDN) showing which attacks are related and which are independent, with an animated replay and evidence on hover. Input: the incident response reports (and optionally Mattermost/Splunk/CloudTrail for verification).

The engine never changes. All content lives in one data file (`data.js`). Your job is to convert the IR reports into `data.js`, build, validate, test and publish.

## Bundle (in `assets/` next to this file)
- `template.html`: the engine (layout, animation, hover evidence, grouped replay, isolate-on-click). Contains the marker `/*__DATA__*/`.
- `data.example.js`: the full Day 1 + Day 2 data (89 events, 51 nodes, 8 clusters). Start day 3 from a copy of this.
- `build.py data.js out.html`: injects the data and runs `validate.js`.
- `validate.js`: syntax check, plus unknown refs, overlapping nodes, bad statuses, missing evidence, undefended IPs.
- `test_map.py out.html shot.png`: Playwright at 1920x947, steps every event, opens every cluster, tests isolate view and page height (must be 947).

Needs: python3, node, Playwright (Chromium). No network.

## Rules for the content
- Read-only research. Never post anywhere. Defang every public IP, domain and URL in text (`18[.]141[.]182[.]12`, `hxxps://`); keep RFC1918 and internal UPNs plain. Never put secrets, PATs, tokens or cookies in the data (truncate, e.g. `glrt-Nqv5…`). Access key IDs may be shown in full.
- Times are SGT. Convert UTC sources explicitly.
- Status per event (`st`) and per evidence entry (`s`): `ok` verified in a source log, `part` partly verified, `bad` not reproduced, `todo` not yet verified, `rep` team-reported (from a report or Mattermost). IR-report claims you have not checked are `rep`, never `ok`.
- Before calling something an IoC, rule out: GCP workload-identity GetCallerIdentity from Google IPs, CloudFront edge IPs, IC / White Cell / Green Team egress (e.g. 61[.]16[.]103[.]154, GCP-IC, Overall-IC), IaC/Terraform and Red-Team setup, recurring jobs. Put those in the "own team / benign" cluster or flag as `Unconfirmed`.

## Workflow
1. **Read the reports** in the project/attachments. Make a list of every attacker action with: time (SGT), source endpoint (IP/host), identity used (user, role, key, session), target asset, technique (ATT&CK ID; ATLAS for AI-agent attacks), source of evidence (CloudTrail event ID, Splunk index, Entra audit, WAF, GitLab, Sysmon), and confidence.
2. **Start from the baseline**: `cp assets/data.example.js data.js`. Update `META` (title, sub, `updated` stamp = time of the last report/Mattermost post, `intro` bullets: what is verified, what is new, what is unchecked, containment status).
3. **Resolve entities** against the existing `N`/`ID` lists before adding anything. The same IP, role or user must reuse the same node row and the same `ID` key, otherwise shared-identity links disappear.
4. **Add nodes** (below), **clusters**, **events**, then **relations**.
5. `python3 assets/build.py data.js out.html`; fix every ERROR and read every WARN.
6. `python3 assets/test_map.py out.html shot.png`; look at the screenshot (nodes readable, nothing overlapping, one open cluster does not push the page over 947px).
7. Publish as an artifact (reuse the slug and `base_version` for updates). Update the project doc with new verified/disputed items.
8. Report briefly: what changed, which events are verified vs team-reported, corrections to earlier days, what is unchecked, sources.

Build the data in small pieces (separate `E_day3_*.js` files appended by a short Python script) instead of one huge tool call.

## data.js schema

`META = {title, sub, updated, updatedTip, intro:[html strings]}`

`C` clusters, keyed `k0..`: `{name, short, rl, color, badge, b, desc}`. `rl` is the short label under the cluster circle in the replay. `b` is the badge class: `b-core` (confirmed chain), `b-rel` (related), `b-ind` (independent), `b-open` (unlinked/open), `b-ben` (likely benign). `CORDER` lists cluster keys in display order. Existing clusters: k1 Day-1 kill chain, k0 pre-exercise foothold, k2 credential replay, k3 HR scan (independent), k4 Wiz packages (unlinked), k5 own team/benign, k6 Day-2 Silver Tiger chain, k7 zachary.low/OpenClaw. Add k8+ for day-3 campaigns. Decide cluster by shared identities, IPs, tooling and C2: related only if one of those is shared; otherwise independent.

`ID` canonical identities `{key: "display name"}`. One key per principal (`caleb`, `mei`, `hdb`, `run`, …). Rows on different endpoints with the same key are the "same identity" links.

`ZONES` background rectangles `{x,y,w,h,l,a?,s?}` (s = sub-zone). Canvas is 1760x1000. Columns: `X1=157` attacker-side endpoints, `X2=457` corporate/identity and other external, `XE=750` edge/serverless, `XC=1010` ECS services, `XA=1295` AWS services/runner/dev S3, `XR=1605` GCP, attacker infrastructure, defender segment. Node x is the centre.

`N` nodes: `{id, l, s, x, y, w, hw?, rows:[{k,l,i}], exp?}`. `l` host or IP (defanged), `s` sub-label (what/where). With `rows` the rectangle is split: endpoint on the left (width `hw`, 110 to 112), identities on the right, one row per identity (17px each; the node height is `max(38, rows*17)`); an endpoint used by several identities gets several rows. Without rows it is a plain asset. `exp` text marks an exposure/misconfiguration (shows a ⚠). Keep a 6px gap between nodes: `validate.js` reports overlaps. Placement: attacker IPs in column X1 (stack downward, leave space), identity systems in X2, prod assets inside the Production zone, dev assets inside the Development zone.

`S` source label strings and `M(src, r)` helper (`{s:"rep", src, r}`) for team-reported evidence; define your own labels per report (e.g. `Reporting · t8_15 (11:44)`).

`E` events (one per attacker action or tight burst):
```
{k:"k6", t:"2026-11-19T10:05", w:"19 Nov 10:05:12", ti:"short action title",
 d:"one or two sentences: what, how, why it matters", segs:[["a1814:ev","gitlab:ev"]], mark:[],
 ioc:["18[.]141[.]182[.]12"], conf:"High", att:"T1550.004", st:"rep",
 ev:[{s:"ok", src:"Splunk · index=waf · aws:cloudwatchlogs:waf", q:"index=waf 18.141.182.12 | stats ...", r:"result in one line"}]}
```
- `segs` are arrows `[from, to]` where each ref is `nodeId` or `nodeId:rowKey`; start from the identity row actually used. Several segments in one event are drawn in sequence.
- `mark` lists refs for host-internal actions (no arrow; the host rectangle pulses). Every event needs `segs` or `mark`.
- `t` ISO local time (sorts the replay); `w` display time/range.
- `ev` entries: `s` status, `src` source as close to the log provider as possible, `q` query or filter used (optional), `r` the result. An event with no evidence is flagged.
- `conf`: High, Medium, Low, Unconfirmed. `att`: ATT&CK IDs (and ATLAS such as AML.T0051).
- The event status is the best status of the key claim; evidence entries carry their own status.

`R` relationships between clusters `{a,b,s,lab,ti,ev:[strings],chk,refs:[refs]}` with `s`: `strong`, `weak`, `none`, `disputed`; `chk` is the next check; `refs` are the shared rows or nodes to highlight. `RPOS` gives the circle positions for the relationship graph (`{k:[x,y]}`, about 340x280 area).

## Quality checks before you publish
- Each IoC and identity in the reports appears on the map or is listed as skipped with a reason.
- Related versus independent is justified by a named shared indicator in an `R` entry.
- Day-3 items that contradict an earlier day are corrected in the earlier event (change `st`, add an evidence entry), not hidden.
- Open containment requests are listed in `META.intro` as "requested, unconfirmed" until White Cell confirms.
