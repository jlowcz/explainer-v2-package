#!/usr/bin/env python3
"""python3 test_map.py out.html [shot.png]: loads at 1920x947, steps every event, opens every cluster, tests isolate view."""
import sys
from playwright.sync_api import sync_playwright
f=sys.argv[1];shot=sys.argv[2] if len(sys.argv)>2 else '/tmp/map.png'
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':1920,'height':947})
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('file://'+f);pg.wait_for_timeout(800)
    n=pg.evaluate('ORDER.length')
    for j in range(n):pg.evaluate(f'goTo({j},true)')
    for k in pg.evaluate('[...document.querySelectorAll(".cg")].map(g=>g.dataset.k)'):
        pg.click(f'.cg[data-k={k}] .cb');pg.wait_for_timeout(100)
        h=pg.evaluate('document.documentElement.scrollHeight')
        if h!=947:errs.append(f'page height {h} with cluster {k} open (must be 947)')
    pg.evaluate('showNode(N[0])');pg.wait_for_timeout(300)
    pg.evaluate('(()=>{const n=N.find(x=>x.rows.length);showIdentity(n.rows[0].i)})()');pg.wait_for_timeout(500)
    iso=pg.evaluate('iso?iso.evs.size:-1')
    pg.click('#isoX');pg.wait_for_timeout(200);pg.evaluate(f'goTo({n}-1,false)')
    pg.screenshot(path=shot)
    print('events',n,'isolate events',iso,'errors',errs or 'none');sys.exit(1 if errs else 0)
