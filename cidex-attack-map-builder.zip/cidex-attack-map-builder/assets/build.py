#!/usr/bin/env python3
"""Usage: python3 build.py data.js out.html
Injects data.js (META, C, CORDER, ID, ZONES, N, S/M helpers, E, R, RPOS) into template.html, then validates."""
import sys,subprocess,os
here=os.path.dirname(os.path.abspath(__file__))
data,out=sys.argv[1],sys.argv[2]
t=open(os.path.join(here,'template.html')).read()
assert '/*__DATA__*/' in t
open(out,'w').write(t.replace('/*__DATA__*/',open(data).read(),1))
r=subprocess.run(['node',os.path.join(here,'validate.js'),out],capture_output=True,text=True)
print(r.stdout+r.stderr)
sys.exit(r.returncode)
