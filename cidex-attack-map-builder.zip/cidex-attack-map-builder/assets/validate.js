// node validate.js out.html : syntax check + data integrity (refs, clusters, statuses, ordering)
const fs=require('fs');const s=fs.readFileSync(process.argv[2],'utf8');
const m=s.match(/<script>([\s\S]*)<\/script>/);let fn;
try{fn=new Function(m[1].split('/* ================= BUILD')[0]+';return {C,CORDER,ID,ZONES,N,E,R,RPOS,META}');}catch(e){console.log('SYNTAX ERROR in data/engine:',e.message);process.exit(2);}
try{new Function(m[1]);}catch(e){console.log('SYNTAX ERROR:',e.message);process.exit(2);}
const {C,CORDER,ID,ZONES,N,E,R,RPOS,META}=fn();
const errs=[],warn=[];const ST=['ok','part','bad','todo','rep'];
const nodes={};N.forEach(n=>{if(nodes[n.id])errs.push('duplicate node '+n.id);nodes[n.id]=n;});
const ref=r=>{const [a,b]=r.split(':');if(!nodes[a])return 'unknown node '+a;if(b&&!(nodes[a].rows||[]).some(x=>x.k===b))return 'unknown row '+r;return null;};
N.forEach(n=>(n.rows||[]).forEach(r=>{if(!ID[r.i])warn.push('row identity not in ID: '+n.id+':'+r.k+' ('+r.i+')');}));
E.forEach((e,i)=>{const w=(e.w||e.ti||i)+'';
 if(!C[e.k])errs.push(w+': unknown cluster '+e.k);
 if(!ST.includes(e.st))errs.push(w+': bad status '+e.st);
 if(!/^\d{4}-\d\d-\d\dT\d\d:\d\d/.test(e.t))errs.push(w+': bad time '+e.t);
 if(!e.ev||!e.ev.length)warn.push(w+': no evidence entries');
 (e.segs||[]).forEach(([a,b])=>[a,b].forEach(r=>{const x=ref(r);if(x)errs.push(w+': '+x);}));
 (e.mark||[]).forEach(r=>{const x=ref(r);if(x)errs.push(w+': '+x);});
 if(!(e.segs||[]).length&&!(e.mark||[]).length)errs.push(w+': needs segs or mark');
 (e.ev||[]).forEach(x=>{if(!ST.includes(x.s))errs.push(w+': bad evidence status '+x.s);});
 if(/(?<![\[\d])\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/.test((e.ti||'')+(e.d||'')))warn.push(w+': possible undefended IP in title/description');
});
CORDER.forEach(k=>{if(!C[k])errs.push('CORDER unknown '+k);});
R.forEach(r=>{[r.a,r.b].forEach(k=>{if(!C[k])errs.push('relation unknown cluster '+k);});(r.refs||[]).forEach(x=>{const e=ref(x);if(e)errs.push('relation '+r.ti+': '+e);});});
Object.keys(C).forEach(k=>{if(!RPOS[k])warn.push('no RPOS for cluster '+k);});
// overlap check
for(let i=0;i<N.length;i++)for(let j=i+1;j<N.length;j++){const a=N[i],b=N[j];const ah=Math.max(38,(a.rows||[]).length*17),bh=Math.max(38,(b.rows||[]).length*17);
 if(Math.abs(a.x-b.x)<(a.w+b.w)/2&&Math.abs(a.y-b.y)<(ah+bh)/2)errs.push('nodes overlap: '+a.id+' / '+b.id);}
console.log('events',E.length,'nodes',N.length,'clusters',Object.keys(C).length);
warn.forEach(x=>console.log('WARN',x));errs.forEach(x=>console.log('ERROR',x));
console.log(errs.length?'FAILED':'OK');process.exit(errs.length?1:0);
